package Application.entity;

public class autodialer_timegroup {

}
