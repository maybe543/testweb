package Application.entity;

public class autodialer_timerange {

}
